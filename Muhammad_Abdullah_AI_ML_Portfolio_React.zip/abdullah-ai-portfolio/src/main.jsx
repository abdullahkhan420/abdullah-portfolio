import React from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUpRight, Download, Github, Linkedin, Mail, MapPin, Phone,
  BrainCircuit, Code2, GraduationCap, Sparkles, Database, Menu, X
} from "lucide-react";
import "./styles.css";

const skills = [
  { name: "Python", group: "Programming", level: "Core", icon: Code2 },
  { name: "C++", group: "Programming", level: "Core", icon: Code2 },
  { name: "OOP", group: "Programming", level: "Core", icon: Code2 },
  { name: "Data Structures & Algorithms", group: "Computer Science", level: "Core", icon: Database },
  { name: "Machine Learning", group: "Artificial Intelligence", level: "Focus", icon: BrainCircuit },
  { name: "Deep Learning", group: "Artificial Intelligence", level: "Focus", icon: BrainCircuit },
];

const projects = [
  {
    number: "01",
    type: "MACHINE LEARNING",
    title: "Machine Learning Projects",
    description: "Course and independent work exploring machine learning concepts, data-driven problem solving, and model development.",
    tags: ["Machine Learning", "Python"],
    note: "Add your project name, dataset, results, and GitHub link here."
  },
  {
    number: "02",
    type: "DEEP LEARNING",
    title: "Deep Learning Projects",
    description: "Practical exploration of deep learning methods and neural-network-based approaches as part of AI learning.",
    tags: ["Deep Learning", "Python"],
    note: "Add your model details, evaluation results, and GitHub link here."
  },
  {
    number: "03",
    type: "PROGRAMMING",
    title: "Python & C++ Applications",
    description: "Small console-based academic applications focused on logic building, modular code, functions, loops, classes, and OOP.",
    tags: ["Python", "C++", "OOP"],
    note: "Add screenshots or a repository link for a completed application."
  }
];

function App() {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="navbar">
        <a className="brand" href="#home" onClick={closeMenu}><span className="brand-mark">A</span><span>ABDULLAH<span className="brand-dot">.</span></span></a>
        <button className="menu-toggle" aria-label="Toggle navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? "nav-links open" : "nav-links"}>
          {["About", "Skills", "Projects", "Education", "Contact"].map((item) =>
            <a key={item} href={`#${item.toLowerCase()}`} onClick={closeMenu}>{item}</a>
          )}
          <a className="nav-cta" href="/Muhammad_Abdullah_CV.pdf" download>Download CV <Download size={15}/></a>
        </nav>
      </header>

      <main>
        <section className="hero section-wrap" id="home">
          <div className="hero-copy">
            <div className="eyebrow"><span className="pulse" /> AI & MACHINE LEARNING PORTFOLIO</div>
            <h1>Building ideas<br/>with <span className="gradient-text">intelligence.</span></h1>
            <p className="hero-intro">I’m <strong>Muhammad Abdullah</strong>, an Artificial Intelligence student interested in building practical solutions through machine learning, deep learning, and software development.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#projects">Explore my work <ArrowUpRight size={17}/></a>
              <a className="button button-ghost" href="/Muhammad_Abdullah_CV.pdf" download><Download size={17}/> Download CV</a>
            </div>
            <div className="hero-meta">
              <span><MapPin size={15}/> Lahore, Pakistan</span>
              <span><Sparkles size={15}/> Learning by building</span>
            </div>
          </div>
          <div className="hero-art" aria-label="Abstract artificial intelligence illustration">
            <div className="orbit orbit-a"></div><div className="orbit orbit-b"></div>
            <div className="core-glow"></div>
            <div className="ai-core"><BrainCircuit size={88} strokeWidth={1.25}/><span>AI</span></div>
            <div className="float-card float-top"><span className="mini-icon"><Code2 size={16}/></span><div><b>Code</b><small>Build · Learn · Improve</small></div></div>
            <div className="float-card float-bottom"><span className="mini-icon"><Database size={16}/></span><div><b>Data-driven</b><small>Ideas into solutions</small></div></div>
            <div className="spark spark-one">✦</div><div className="spark spark-two">✧</div>
          </div>
          <div className="hero-scroll">SCROLL TO EXPLORE <span></span></div>
        </section>

        <section className="section-wrap section" id="about">
          <div className="section-heading"><span className="section-kicker">01 / ABOUT</span><h2>A little <span className="gradient-text">about me.</span></h2></div>
          <div className="about-grid">
            <div className="about-lead"><p>I’m pursuing a Bachelor’s degree in Artificial Intelligence at the University of Management and Technology. I enjoy strengthening my programming fundamentals while exploring the possibilities of machine learning and deep learning.</p><p>My goal is to keep learning, work on meaningful projects, and grow as an AI/ML engineer through hands-on experience and real-world problem solving.</p></div>
            <div className="about-stats">
              <div className="stat-card"><span className="stat-icon"><GraduationCap/></span><b>BS Artificial Intelligence</b><small>UMT · 2024–2028</small></div>
              <div className="stat-card"><span className="stat-icon"><BrainCircuit/></span><b>AI Focus</b><small>Machine Learning & Deep Learning</small></div>
              <div className="stat-card"><span className="stat-icon"><Code2/></span><b>Programming</b><small>Python · C++ · OOP</small></div>
            </div>
          </div>
        </section>

        <section className="section-wrap section" id="skills">
          <div className="section-heading"><span className="section-kicker">02 / TOOLKIT</span><h2>Skills I’m <span className="gradient-text">developing.</span></h2><p className="section-subtitle">A growing foundation in programming and artificial intelligence.</p></div>
          <div className="skills-grid">{skills.map(({name, group, level, icon: Icon}) => <div className="skill-card" key={name}><div className="skill-top"><span className="skill-icon"><Icon size={20}/></span><span className="skill-level">{level}</span></div><h3>{name}</h3><p>{group}</p></div>)}</div>
        </section>

        <section className="section-wrap section" id="projects">
          <div className="section-heading"><span className="section-kicker">03 / SELECTED WORK</span><h2>Learning through <span className="gradient-text">projects.</span></h2><p className="section-subtitle">A snapshot of the areas I’ve worked on during my academic journey.</p></div>
          <div className="projects-grid">{projects.map((project) => <article className="project-card" key={project.number}><div className="project-top"><span className="project-number">{project.number}</span><span className="project-type">{project.type}</span></div><div className="project-art"><div className="project-orb"><BrainCircuit size={43}/></div><span className="art-line line-one"/><span className="art-line line-two"/><span className="art-dot dot-one"/><span className="art-dot dot-two"/></div><h3>{project.title}</h3><p>{project.description}</p><div className="tag-row">{project.tags.map(tag => <span key={tag}>{tag}</span>)}</div><div className="project-note">{project.note}</div></article>)}</div>
        </section>

        <section className="section-wrap section" id="education">
          <div className="section-heading"><span className="section-kicker">04 / EDUCATION</span><h2>The learning <span className="gradient-text">journey.</span></h2></div>
          <div className="timeline">
            <div className="timeline-item"><span className="timeline-dot"/><div className="timeline-date">2024 — 2028</div><div className="timeline-content"><h3>Bachelor in Artificial Intelligence</h3><p>University of Management and Technology</p><span className="timeline-label">UNDERGRADUATE</span></div></div>
            <div className="timeline-item"><span className="timeline-dot"/><div className="timeline-date">2021 — 2023</div><div className="timeline-content"><h3>Intermediate</h3><p>Punjab Group of College</p><span className="timeline-label">COLLEGE</span></div></div>
          </div>
        </section>

        <section className="contact-section" id="contact">
          <div className="section-wrap contact-inner"><div><span className="section-kicker">05 / GET IN TOUCH</span><h2>Let’s create something<br/><span className="gradient-text">meaningful.</span></h2><p>I’m open to learning opportunities, collaborations, and conversations about AI and technology.</p></div><div className="contact-card"><a href="mailto:muhammad.abdullah.pk.111@gmail.com"><Mail size={19}/><span><small>EMAIL</small>muhammad.abdullah.pk.111@gmail.com</span><ArrowUpRight size={17}/></a><a href="tel:+923354139420"><Phone size={19}/><span><small>PHONE</small>+92 335 4139420</span><ArrowUpRight size={17}/></a><div className="contact-location"><MapPin size={19}/><span><small>LOCATION</small>Johar Town, Lahore, Pakistan</span></div></div></div>
        </section>
      </main>
      <footer className="footer"><a className="brand" href="#home"><span className="brand-mark">A</span><span>ABDULLAH<span className="brand-dot">.</span></span></a><span>Designed & built with curiosity.</span><a href="#home" className="back-top">BACK TO TOP ↑</a></footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<React.StrictMode><App /></React.StrictMode>);