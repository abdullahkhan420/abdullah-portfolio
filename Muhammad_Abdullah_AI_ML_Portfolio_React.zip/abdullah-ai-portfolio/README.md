# Muhammad Abdullah — AI/ML Engineer Portfolio

A responsive React portfolio built with Vite and a blue-gradient visual theme.

## Run locally

1. Install Node.js (LTS).
2. Extract this project folder.
3. Open a terminal in the folder and run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL printed by Vite (usually http://localhost:5173).

## Build for deployment

```bash
npm run build
```

The production site is generated in `dist/`.

## Deploy

You can import this folder/repository into Vercel or Netlify. Use the default Vite build command `npm run build` and output folder `dist`.

## Personalize your projects

The CV mentions Machine Learning and Deep Learning projects, but does not list project names or repository URLs. The project cards therefore use honest category-level summaries and include notes showing where to add your actual project names, results, and GitHub links. Edit the `projects` array in `src/main.jsx`.

## CV

The provided CV is included at `public/Muhammad_Abdullah_CV.pdf`. Replace it with a newer version if needed, keeping the same filename.
